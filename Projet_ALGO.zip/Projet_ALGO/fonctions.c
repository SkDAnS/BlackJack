#include <stdlib.h>
#include <stdio.h>
#include <math.h>	// Pour pouvoir utiliser sin() et cos()
#include "GfxLib.h" // Seul cet include est necessaire pour faire du graphique
#include "BmpLib.h" // Cet include permet de manipuler des fichiers BMP
#include "ESLib.h"	// Pour utiliser valeurAleatoire()
#include <string.h>
#include <time.h>
#include <unistd.h>
#include "fonctions.h"
#include "moteur.h"

#include "settings.h"





valeurs init_val() {
	valeurs vals ={0}; 
	vals.distancelargeur = 85;
	vals.distancehauteur = 70;
	vals.rayoncercle = 30;
	vals.rayoncercle2 = 25;
	vals.rayongroscercle = 60;
	vals.rayongroscercle2 = 50;

	return vals ;
}


int nbr;
int nbrInitial = 100;
int nbr2 = 0;
int choixPartie = 0;
int verif =0;

int valeurBot = 0;
int valeurJoueur = 0;

int variableboutonf2unef = 0;
struct main valeur_main = {0};


/* Fonction de trace de cercle */
void cercle(float centreX, float centreY, float rayon){
	const int Pas = 20; // Nombre de secteurs pour tracer le cercle
	const double PasAngulaire = 2. * M_PI / Pas;
	int index;

	for (index = 0; index < Pas; ++index) // Pour chaque secteur
	{
		const double angle = 2. * M_PI * index / Pas; // on calcule l'angle de depart du secteur
		triangle(centreX, centreY,
				 centreX + rayon * cos(angle), centreY + rayon * sin(angle),
				 centreX + rayon * cos(angle + PasAngulaire), centreY + rayon * sin(angle + PasAngulaire));
		// On trace le secteur a l'aide d'un triangle => approximation d'un cercle
	}
}


void afficheFondecran(){
	// Ligne transversale
	couleurCourante(36, 255, 255);
	epaisseurDeTrait(25);
	ligne(largeurFenetre(), 0, 0, hauteurFenetre());
	// Rectangle
	couleurCourante(12, 109, 17);
	rectangle(0, 0, (largeurFenetre()), (hauteurFenetre()));
	
}



void cercleBot(valeurs vals, struct main *main_croupier, struct test *POMME){

	// cercle joueur
	couleurCourante(36, 64, 37);
	cercle(((2 * largeurFenetre()) / 3) + 50, (2 * hauteurFenetre()) / 3, vals.rayoncercle);
	couleurCourante(255,255,255);
	epaisseurDeTrait(1);
	
	char tabbot[5] = {0};
	POMME->pomme1 = calculerValeurMain(main_croupier);
    sprintf(tabbot , "%d", afficherValeurMain(main_croupier));
	
 	afficherValeurMain(main_croupier);
	
	
	afficheChaine(tabbot, 20, ((2 * largeurFenetre()) / 3) + 43, ((2 * hauteurFenetre()) / 3) - 7) ;
	afficheChaine("Bot", 20, ((2 * largeurFenetre()) / 3) + 100, ((2 * hauteurFenetre()) / 3) - 7);


}


void cercleJoueur(valeurs vals, struct main *main_joueur, struct test *POMME) {

    // cercle croupier
    couleurCourante(36, 64, 37);
    cercle(((2 * largeurFenetre()) / 3) + 50, hauteurFenetre() / 3, vals.rayoncercle);

    couleurCourante(255,255,255);
    epaisseurDeTrait(1);
	char tab[5] = {0};
	POMME->pomme = afficherValeurMain(main_joueur);
    sprintf(tab , "%d", afficherValeurMain(main_joueur));
    
 	afficherValeurMain(main_joueur);
	
	

    afficheChaine(tab, 20, ((2 * largeurFenetre()) / 3) + 43, (hauteurFenetre() / 3) - 7);
    afficheChaine("Joueur", 20, ((2 * largeurFenetre()) / 3) + 100, (hauteurFenetre() / 3) - 7);
}




void cercle1(valeurs vals){

	// Cercle 1
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle);
	couleurCourante(0, 0, 0);
	cercle(largeurFenetre() / 20 + vals.distancelargeur, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2);
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2 - 1);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("1", 10, (largeurFenetre() / 20 + vals.distancelargeur) - 3, ((hauteurFenetre()) / 3 - vals.distancehauteur) - 3);

}

void cercle5(valeurs vals){

	// Cercle 5
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 2, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle);
	couleurCourante(255, 0, 0);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 2, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("5", 10,(largeurFenetre() / 20 + vals.distancelargeur * 2) - 3,((hauteurFenetre()) / 3 - vals.distancehauteur ) - 3);

}


void cercle25(valeurs vals){

	// Cercle 25
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 3, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle);
	couleurCourante(0, 255, 0);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 3, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("25",10, (largeurFenetre() / 20 + vals.distancelargeur * 3) - 6,((hauteurFenetre()) / 3 - vals.distancehauteur) - 3);

}

void cercle50(valeurs vals){

	// Cercle 50
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 4, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle);
	couleurCourante(60, 94, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 4, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("50",10, (largeurFenetre() / 20 + vals.distancelargeur * 4) - 6,((hauteurFenetre()) / 3 - vals.distancehauteur) - 3);

}

void cercle100(valeurs vals){

	// Cercle 100
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 5, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle);
	couleurCourante(178, 175, 172);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 5, (hauteurFenetre()) / 3 - vals.distancehauteur, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("100",10, (largeurFenetre() / 20 + vals.distancelargeur * 5) -9,((hauteurFenetre()) / 3 - vals.distancehauteur) - 3);

}

void cercle500(valeurs vals){

	// Cercle 500
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur, (hauteurFenetre()) / 3 - vals.distancehauteur * 3, vals.rayoncercle);
	couleurCourante(107, 43, 178);
	cercle(largeurFenetre() / 20 + vals.distancelargeur, (hauteurFenetre()) / 3 - vals.distancehauteur * 3, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("500",10, (largeurFenetre() / 20 + vals.distancelargeur) - 9,((hauteurFenetre()) / 3 - vals.distancehauteur * 3) - 3);

}

void cercle1000(valeurs vals){

	// Cercle 1000
	couleurCourante(255, 255, 255);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 2, (hauteurFenetre()) / 3 - vals.distancehauteur * 3, vals.rayoncercle);
	couleurCourante(204, 235, 31);
	cercle(largeurFenetre() / 20 + vals.distancelargeur * 2, (hauteurFenetre()) / 3 - vals.distancehauteur * 3, vals.rayoncercle2);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(0.5);
	afficheChaine("1000",10, (largeurFenetre() / 20 + vals.distancelargeur * 2) - 12,((hauteurFenetre()) / 3 - vals.distancehauteur * 3) - 3) ;

}


void affichePlaceBanque(valeurs vals){

	// Rectangle bleu
	couleurCourante(10, 65, 84);
	rectangle(largeurFenetre() / 20, 0, (2 * largeurFenetre()) / 3, (hauteurFenetre()) / 3);
	// Rectangle total
	couleurCourante(10, 65, 84);
	rectangle(largeurFenetre() / 20, (hauteurFenetre()) / 3, (largeurFenetre() / 3), (hauteurFenetre()) / 3 + vals.distancehauteur);
	
	couleurCourante(255,255,255);
	ligne(largeurFenetre() / 20, (hauteurFenetre()) / 3, largeurFenetre() / 20, 0);
	ligne(largeurFenetre() / 20, (hauteurFenetre()) / 3 + vals.distancehauteur, largeurFenetre() / 20, (hauteurFenetre()) / 3);
	ligne(largeurFenetre() / 20, (hauteurFenetre()) / 3 + vals.distancehauteur,(largeurFenetre() / 3) ,(hauteurFenetre()) / 3 + vals.distancehauteur);
	ligne((largeurFenetre() / 3), (hauteurFenetre()) / 3, (2 * largeurFenetre()) / 3,(hauteurFenetre()) / 3);
	epaisseurDeTrait(10);
	
}


void BoutonTout(valeurs vals,char tab[5]){


	couleurCourante(40, 97, 208 );
	rectangle(((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 , (((hauteurFenetre()) / 3) ), 
		(largeurFenetre() / 3) - (largeurFenetre() / 20) , ((hauteurFenetre()) / 3 + (25+7.25)));

	couleurCourante(255,255,255);
	ligne(((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 , ((hauteurFenetre()) / 3 + (25+7.25)),(largeurFenetre() / 3) - (largeurFenetre() / 20) , ((hauteurFenetre()) / 3 + (25+7.25)));
	ligne(((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 , ((hauteurFenetre()) / 3 + (25+7.25)), ((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 , (((hauteurFenetre()) / 3) ));
	epaisseurDeTrait(7);


	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("TOUT",15, ((((largeurFenetre() / 3) - (largeurFenetre() / 20)) + (((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5)) / 2) *(0.93),
		((((hauteurFenetre()) / 3 + (25+7.25)) +(((hauteurFenetre()) / 3) )) / 2) * 0.97) ;

	couleurCourante(255,255,255);
	afficheChaine("Banq. $", 15, ((((largeurFenetre() / 3) - (largeurFenetre() / 20)) + (((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5)) / 2) *(0.23),(((((hauteurFenetre()) / 3 + (25+7.25)) +(((hauteurFenetre()) / 3) )) / 2) * 0.97) + 40);

	afficheChaine(tab , 15, ((((largeurFenetre() / 3) - (largeurFenetre() / 20)) + (((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5)) / 2) *(0.47),(((((hauteurFenetre()) / 3 + (25+7.25)) +(((hauteurFenetre()) / 3) )) / 2) * 0.97) + 40);


}

void affichepetiteBanque(valeurs vals,char tab3[5]){

	couleurCourante(10, 65, 84);
	rectangle(largeurFenetre() / 20, 0, (largeurFenetre() / 3), 35 );

	couleurCourante(255,255,255);
	ligne(largeurFenetre() / 20, 35, largeurFenetre() / 20, 0);
	ligne(largeurFenetre() / 20, 35, (largeurFenetre() / 3), 35);
	epaisseurDeTrait(7);

	couleurCourante(255,255,255);
	epaisseurDeTrait(1);
	afficheChaine("Banq. $", 15, ((((largeurFenetre() / 3) - (largeurFenetre() / 20)) + (((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5)) / 2) *(0.23),15);


	afficheChaine(tab3 , 15, ((((largeurFenetre() / 3) - (largeurFenetre() / 20)) + (((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5)) / 2) *(0.47),15);

}

void NombreaudessusGros(valeurs vals,char tab[5]){

	couleurCourante(255,255,255);
	epaisseurDeTrait(1);
	afficheChaine("$",20, ((hauteurFenetre()) / 1.75) + 80, ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.23);
	afficheChaine(tab, 20, ((hauteurFenetre()) / 1.75) + 100, ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.23);
	afficheChaine(tab, 20, ((hauteurFenetre()) / 1.75) + 100 , ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.23);
}

void GrosCercle1(valeurs vals){

	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(0, 0, 0);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2 - 1);
	couleurCourante(0, 0, 0);
	epaisseurDeTrait(1);
	afficheChaine("1", 20, ((hauteurFenetre()) / 1.75) - 6, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
	
}

void GrosCercle5(valeurs vals){

	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(255, 0, 0);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("5", 20, ((hauteurFenetre()) / 1.75) - 6, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
	
	
}

void GrosCercle25(valeurs vals){

	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(0, 255, 0);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("25", 20, ((hauteurFenetre()) / 1.75) - 12, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
	
	
}

void GrosCercle50(valeurs vals){



	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(60, 94, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("50", 20, ((hauteurFenetre()) / 1.75) - 12, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
	
	

}
void GrosCercle100(valeurs vals){
	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(178, 175, 172);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("100", 20, ((hauteurFenetre()) / 1.75) - 18, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);

}
void GrosCercle500(valeurs vals){

	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(107, 43, 178);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("500", 20, ((hauteurFenetre()) / 1.75) - 18, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
}

void GrosCercle1000(valeurs vals){



	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(204, 235, 31);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("1000", 20, ((hauteurFenetre()) / 1.75) - 24, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 6);
	
	

}

void afficheBoutonJouer(int r, int g, int v)
{

	couleurCourante(r, g, v);
	rectangle(largeurFenetre() / 2 - 120, hauteurFenetre() / 2 - 100, largeurFenetre() / 2 + 120, hauteurFenetre() / 2 - 20);
	epaisseurDeTrait(0.2);
	couleurCourante(0, 0, 0);
	afficheChaine("JOUER", 55, largeurFenetre() / 2 - 100, hauteurFenetre() / 2 - 90);
}

void afficheBoutonOK(int r, int g, int v)
{

	couleurCourante(r, g, v);
	rectangle(largeurFenetre() / 2 - 110, hauteurFenetre() / 2 - 350, largeurFenetre() / 2 + 100, hauteurFenetre() / 2 - 275);
	epaisseurDeTrait(0.2);
	couleurCourante(0, 0, 0);
	afficheChaine("JOUER", 55, largeurFenetre() / 2 - 100, hauteurFenetre() / 2 - 340);
	couleurCourante(255,255,255);
	ligne(largeurFenetre() / 2 - 110,hauteurFenetre() / 2 - 275,largeurFenetre() / 2 + 100,hauteurFenetre() / 2 - 275);
	ligne(largeurFenetre() / 2 - 110,hauteurFenetre() / 2 - 275,largeurFenetre() / 2 - 110,hauteurFenetre() / 2 - 350);
	epaisseurDeTrait(10);
}

void afficheBoutonRester(valeurs vals,int r,int g, int v){
	
	couleurCourante(r, g, v);
	rectangle((3*largeurFenetre())/5.7, hauteurFenetre()/2-vals.distancehauteur/2 + 35, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43, hauteurFenetre()/2+vals.distancehauteur/2);
	epaisseurDeTrait(0.5);
	couleurCourante(0,0,0);
	afficheChaine("Rester", 15, ((((3*largeurFenetre())/4+vals.distancelargeur) / 1.43) - ((3*largeurFenetre())/5.7)) / 2 + (3*largeurFenetre())/5.7 - 21, ((hauteurFenetre()/2+vals.distancehauteur/2) - (hauteurFenetre()/2-vals.distancehauteur/2 + 35)) / 2 + (hauteurFenetre()/2-vals.distancehauteur/2 + 35) - 5);

	couleurCourante(255,255,255);
	ligne((3*largeurFenetre())/5.7,hauteurFenetre()/2+vals.distancehauteur/2,(3*largeurFenetre())/5.7,hauteurFenetre()/2-vals.distancehauteur/2 + 35);
	ligne((3*largeurFenetre())/5.7, hauteurFenetre()/2+vals.distancehauteur/2,((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 ,hauteurFenetre()/2+vals.distancehauteur/2);
	epaisseurDeTrait(15);

}

void afficheBoutonAjouterCarte(valeurs vals,int r,int g, int v){
	
	couleurCourante(r, g, v);
	rectangle((3*largeurFenetre())/17.1, hauteurFenetre()/2-vals.distancehauteur/2 + 35, ((3*largeurFenetre())/4+vals.distancelargeur) / 3.66, hauteurFenetre()/2+vals.distancehauteur/2);
	epaisseurDeTrait(0.5);
	couleurCourante(0,0,0);
	afficheChaine("Distr.", 15, ((((3*largeurFenetre())/4+vals.distancelargeur) / 1.43) - ((3*largeurFenetre())/5.7)) / 2 + (3*largeurFenetre())/17.1 - 21, ((hauteurFenetre()/2+vals.distancehauteur/2) - (hauteurFenetre()/2-vals.distancehauteur/2 + 35)) / 2 + (hauteurFenetre()/2-vals.distancehauteur/2 + 35) - 5);

	couleurCourante(255,255,255);
	ligne((3*largeurFenetre())/17.1,hauteurFenetre()/2+vals.distancehauteur/2 ,(3*largeurFenetre())/17.1,hauteurFenetre()/2-vals.distancehauteur/2 + 35);
	ligne((3*largeurFenetre())/17.1, hauteurFenetre()/2+vals.distancehauteur/2, ((3*largeurFenetre())/4+vals.distancelargeur) / 3.66,hauteurFenetre()/2+vals.distancehauteur/2);
	epaisseurDeTrait(15);

}

void BoutonDONNE(valeurs vals,int r, int g, int v){

	couleurCourante(r, g, v);
	rectangle((3*largeurFenetre())/5.7 - 10, hauteurFenetre()/2-vals.distancehauteur/2 + 25, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 + 10, hauteurFenetre()/2+vals.distancehauteur/2 + 10);
	epaisseurDeTrait(0.5);
	couleurCourante(255,255,255);
	ligne((3*largeurFenetre())/5.7 - 10, hauteurFenetre()/2+vals.distancehauteur/2 + 9, 3*largeurFenetre()/5.7 + 68,hauteurFenetre()/2+vals.distancehauteur/2 + 9);
	ligne((3*largeurFenetre())/5.7 - 10,hauteurFenetre()/2+vals.distancehauteur/2 + 10, (3*largeurFenetre())/5.7 - 10,hauteurFenetre()/2-vals.distancehauteur/2 + 24);
	
	couleurCourante(0,0,0);
	afficheChaine("Donne", 15, ((((3*largeurFenetre())/4+vals.distancelargeur) / 1.43) - ((3*largeurFenetre())/5.7)) / 2 + (3*largeurFenetre())/5.7 - 21, ((hauteurFenetre()/2+vals.distancehauteur/2) - (hauteurFenetre()/2-vals.distancehauteur/2 + 35)) / 2 + (hauteurFenetre()/2-vals.distancehauteur/2 + 35) - 5);

}


void GagnerBas(valeurs vals){

	couleurCourante(99, 255, 103); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("G", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 113);

	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136,  ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136);

}

void PerdueHaut(valeurs vals){

	couleurCourante(255, 99, 99 ); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("P", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 479);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230);


}

void PerdueBas(valeurs vals){

	couleurCourante(255, 99, 99); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("P", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 113);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136,  ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136);

	
}

void GagnerHaut(valeurs vals){

	couleurCourante(99, 255, 103); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	
	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("G", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 479);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230);


}

void EgaliterHaut(valeurs vals){
	couleurCourante(0,0,0);
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	couleurCourante(255, 255, 255); 
	
	epaisseurDeTrait(0.5);
	afficheChaine("=", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 479);

	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 185);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) + 230);


}

void EgaliterBas(valeurs vals){
	couleurCourante(0,0,0);
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	couleurCourante(255, 255, 255); 
	
	epaisseurDeTrait(0.5);
	afficheChaine("=", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37))
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 113);

	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136, ((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136,  ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136);

}

void BlocAbondon(valeurs vals,char tab8[50]){

	couleurCourante(0,0,0);
	rectangle( LargeurFenetre / 10, HauteurFenetre / 10, (9*LargeurFenetre) / 10, (9*HauteurFenetre) / 10);
	couleurCourante(255,255,255);
	epaisseurDeTrait(3);
	afficheChaine("Abondon", 50, (((9*LargeurFenetre) / 10) - (LargeurFenetre / 10)) / 2, (((9*HauteurFenetre) / 10) - (HauteurFenetre / 10)) / 2 + LargeurFenetre / 10);
	afficheChaine("Vous accumulez : $ ", 40, (((9*LargeurFenetre) / 10) - (LargeurFenetre / 10)) / 2 - 300, (((9*HauteurFenetre) / 10) - (HauteurFenetre / 10)) / 2);
	afficheChaine(tab8, 40, (((9*LargeurFenetre) / 10) - (LargeurFenetre / 10)) / 2 + 160, (((9*HauteurFenetre) / 10) - (HauteurFenetre / 10)) / 2);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(LargeurFenetre / 10, HauteurFenetre / 10, LargeurFenetre / 10,(9*HauteurFenetre) / 10);
	ligne(LargeurFenetre / 10, (9*HauteurFenetre) / 10, (9*LargeurFenetre) / 10,(9*HauteurFenetre) / 10);
}

void BlocGameOver(valeurs vals){

	couleurCourante(0,0,0);
	rectangle( LargeurFenetre / 10, HauteurFenetre / 10, (9*LargeurFenetre) / 10, (9*HauteurFenetre) / 10);
	couleurCourante(255,255,255);
	epaisseurDeTrait(3);
	afficheChaine("GAME OVER", 50, (((9*LargeurFenetre) / 10) - (LargeurFenetre / 10)) / 2 - 60, (((9*HauteurFenetre) / 10) - (HauteurFenetre / 10)) / 2 + LargeurFenetre / 10 - 50);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(LargeurFenetre / 10, HauteurFenetre / 10, LargeurFenetre / 10,(9*HauteurFenetre) / 10);
	ligne(LargeurFenetre / 10, (9*HauteurFenetre) / 10, (9*LargeurFenetre) / 10,(9*HauteurFenetre) / 10);

}


void DoubleouRien(valeurs vals){

	couleurCourante(255, 255, 255);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle);
	couleurCourante(21, 206, 60);
	cercle(((hauteurFenetre()) / 1.75), ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25, vals.rayongroscercle2);
	couleurCourante(0,0,0);
	epaisseurDeTrait(0.1);
	afficheChaine("Doubler", 10, ((hauteurFenetre()) / 1.75) - 20, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) +20);
	epaisseurDeTrait(1);
	afficheChaine("X2", 40, ((hauteurFenetre()) / 1.75) - 23, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 30);

}

void petitBoutonAbandoner(valeurs vals){

	couleurCourante(224, 255, 0); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 300  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250);

	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("Abandonner", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37) - 167)
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 43);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206,((hauteurFenetre()) / 1.75) / 2 + 40,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 40, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206,((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 300, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206);


}

void petitBoutonContinuer(valeurs vals){

	couleurCourante(224, 255, 0); 
	rectangle(((hauteurFenetre()) / 1.75) / 2 + 290, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206, ((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50  ,(((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250);

	couleurCourante(0,0,0);
	epaisseurDeTrait(1);
	afficheChaine("Continuer", 20,(((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 180)-( (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 136)) / 2 + ((((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.37) + 95)
		, ((((hauteurFenetre()) / 1.75) - (((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50) / 2))  + 43);
	epaisseurDeTrait(3);
	couleurCourante(255,255,255);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 290, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206,((hauteurFenetre()) / 1.75) / 2 + 290, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250);
	ligne(((hauteurFenetre()) / 1.75) / 2 + 290, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206,((3*largeurFenetre())/4+vals.distancelargeur) / 1.43 - 50, (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206);


}










void Partie0(valeurs vals )
{
	choixPartie = 0;
	
	afficheBoutonOK(182, 67, 25);
}


int Partie1(valeurs vals){

	choixPartie = 1;
	//afficheFondecran();
	affichePlaceBanque(vals);
	cercle1(vals);
	cercle5(vals);
	cercle25(vals);
	cercle50(vals);
	cercle100(vals);
	cercle500(vals);
	cercle1000(vals);
	int xjeton = abscisseSouris();
	int yjeton = ordonneeSouris();
	int xtout = abscisseSouris();
	int ytout = ordonneeSouris();

	static int dernierGrosCercle = 0;

	
	char tab[5];
    sprintf(tab, "%d", nbr);
    BoutonTout(vals,tab); 

    char tab2[5];
    sprintf(tab2, "%d", nbr2);
    NombreaudessusGros(vals,tab2); 

    if (xjeton <= (largeurFenetre() / 20) + vals.distancelargeur + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle ){
      	
      	if(nbr >= 1 || nbr >= nbr - 1){

      		GrosCercle1(vals);
        	dernierGrosCercle = 1;
        	

      	}

      	
    	

      	
      	
        
    }

	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur * 2 + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur * 2 - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle ){
    	
    	//corriger le fait que on reappuie dessus et le jeton gros apparait. met le gros jeton tout seul en condition

		

		if (nbr >= 5 || nbr >= nbr- 5){
        GrosCercle5(vals);
        dernierGrosCercle = 5;
    	}

    	
    	
    	
	}


	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur * 3 + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur * 3 - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle ){
    	
		if(nbr >= 25 || nbr >= nbr - 25){
			
    		dernierGrosCercle = 25;
    		GrosCercle25(vals);
    	
		}
    	
    	
	}

	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur * 4 + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur * 4 - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle ){
    	if(nbr >= 50 || nbr >= nbr - 50){
    		
    		dernierGrosCercle = 50;
    		GrosCercle50(vals);
    		
    	}
    	
    	
	}

	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur * 5 + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur * 5 - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle ){
    	
    	if(nbr >= 100 || nbr >= nbr - 100){
    		GrosCercle100(vals);
    		dernierGrosCercle = 100;

    	}
    	
    	
	}

	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 - vals.rayoncercle ){
    	if(nbr >= 500 || nbr >= nbr - 500){
    		GrosCercle500(vals);
    		dernierGrosCercle = 500;

    		
    	}
    	
    	
	}

	else if(xjeton <= largeurFenetre() / 20 + vals.distancelargeur * 2 + vals.rayoncercle && xjeton >= largeurFenetre() / 20 + vals.distancelargeur * 2 - vals.rayoncercle && yjeton <= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 + vals.rayoncercle && yjeton >= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 - vals.rayoncercle ){
    	if(nbr >= 1000 || nbr >= nbr - 1000){
    		GrosCercle1000(vals);
    		dernierGrosCercle = 1000;

    		
    	}
    	
    	
	}

	else if (xjeton <= ((hauteurFenetre()) / 1.75) + vals.rayongroscercle && xjeton >= ((hauteurFenetre()) / 1.75) - vals.rayongroscercle && yjeton <= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 + vals.rayongroscercle && yjeton >= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 - vals.rayongroscercle) {
       	
       		dernierGrosCercle = 0;
       		

    }

    if (xtout >= ((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 && xtout <= (largeurFenetre() / 3) - (largeurFenetre() / 20) && ytout >= (((hauteurFenetre()) / 3) ) && ytout <= ((hauteurFenetre()) / 3 + (25+7.25))){

    	if(nbrInitial <= 4 ){
    		GrosCercle1(vals);
    	}
    	else if (nbrInitial < 25 && nbrInitial >= 5){
    		GrosCercle5(vals);
    	}
    	else if (nbrInitial < 50 && nbrInitial >= 25){
    		GrosCercle25(vals);
    	}
    	else if (nbrInitial < 100 && nbrInitial >= 50){
    		GrosCercle50(vals);
    	}
    	else if (nbrInitial < 500 && nbrInitial >= 100){
    		GrosCercle100(vals);
    	}
    	else if (nbrInitial < 1000 && nbrInitial >= 500){
    		GrosCercle500(vals);
    	}
    	else{
    		GrosCercle1000(vals);
    	}
    }
    
	else{
    	switch(dernierGrosCercle) {
        	case 1:
            	GrosCercle1(vals);
           	break;
        	case 5:
            	GrosCercle5(vals);
            break;
        	case 25:
            	GrosCercle25(vals);
            break;
        	case 50:
            	GrosCercle50(vals);
            break;
        	case 100:
            	GrosCercle100(vals);
            break;
        	case 500:
            	GrosCercle500(vals);
            break;
        	case 1000:
            	GrosCercle1000(vals);
            break;
        	default:
            // Aucune action
            break;


    	}
    		}



	BoutonDONNE(vals,70, 81, 255);

	

	return nbr;
	
}


void Partie2(valeurs vals, struct main *main_joueur, struct main *main_croupier, struct test *POMME){
	choixPartie = 2;
	
  	

	char tab[5]= {0};
    sprintf(tab, "%d", nbr);
  	

	affichepetiteBanque(vals,tab);

	afficheBoutonRester(vals,88, 216, 57 );
	afficheBoutonAjouterCarte(vals,88,216,57);
	

	DoubleouRien(vals);
	

	// cercleBot(vals,main_croupier, POMME);

	
	
	 
	

	cercleJoueur(vals, main_joueur,POMME);  // Passez l'adresse de la variable à la fonction cercleJoueur



    sprintf(tab, "%d", nbr2);
	NombreaudessusGros(vals,tab);
	


}


void Partie3_1(valeurs vals){

	choixPartie = 31;


	
	GagnerHaut(vals);
	PerdueBas(vals);
	petitBoutonContinuer(vals);
	petitBoutonAbandoner(vals);

	char tab[5];
    sprintf(tab, "%d", nbr);
	affichepetiteBanque(vals,tab);
	affichepetiteBanque(vals,tab);
	
}

void Partie3_2(valeurs vals){

	choixPartie = 32;

	

	//afficheFondecran();
	GagnerBas(vals);
	PerdueHaut(vals);
	petitBoutonContinuer(vals);
	petitBoutonAbandoner(vals);

	char tab[5];
    sprintf(tab, "%d", nbr);
	affichepetiteBanque(vals,tab);
	affichepetiteBanque(vals,tab);


}

void Partie3_3(valeurs vals){

	choixPartie = 33;

	

	//afficheFondecran();
	EgaliterBas(vals);
	EgaliterHaut(vals);
	petitBoutonContinuer(vals);
	petitBoutonAbandoner(vals);

	char tab[5];
    sprintf(tab, "%d", nbr);
	affichepetiteBanque(vals, tab);
	affichepetiteBanque(vals, tab);


}
void Partie4_1(valeurs vals){

	

	char tab[50];
    sprintf(tab, "%d", nbr);
	BlocAbondon(vals,tab);

}

void Partie4_2(valeurs vals){

	

	BlocGameOver(vals);

}



// Fonction qui implémente les images des cartes 
void implementerImagesStatiques(struct carte tas[NUM_CARTES]) {
		
	// Trèfle
	tas[0].image = lisBMPRGB("./images_cartes/as-trefle.bmp");
	tas[1].image = lisBMPRGB("./images_cartes/deux-trefle.bmp");
	tas[2].image = lisBMPRGB("./images_cartes/trois-trefle.bmp");
	tas[3].image = lisBMPRGB("./images_cartes/quatre-trefle.bmp");
	tas[4].image = lisBMPRGB("./images_cartes/cinq-trefle.bmp");
	tas[5].image = lisBMPRGB("./images_cartes/six-trefle.bmp");
	tas[6].image = lisBMPRGB("./images_cartes/sept-trefle.bmp");
	tas[7].image = lisBMPRGB("./images_cartes/huit-trefle.bmp");
	tas[8].image = lisBMPRGB("./images_cartes/neuf-trefle.bmp");
	tas[9].image = lisBMPRGB("./images_cartes/dix-trefle.bmp");
	tas[10].image = lisBMPRGB("./images_cartes/valet-trefle.bmp");
	tas[11].image = lisBMPRGB("./images_cartes/dame-trefle.bmp");
	tas[12].image = lisBMPRGB("./images_cartes/roi-trefle.bmp");

	// Carreau
	tas[13].image = lisBMPRGB("./images_cartes/as-carreau.bmp");
	tas[14].image = lisBMPRGB("./images_cartes/deux-carreau.bmp");
	tas[15].image = lisBMPRGB("./images_cartes/trois-carreau.bmp");
	tas[16].image = lisBMPRGB("./images_cartes/quatre-carreau.bmp");
	tas[17].image = lisBMPRGB("./images_cartes/cinq-carreau.bmp");
	tas[18].image = lisBMPRGB("./images_cartes/six-carreau.bmp");
	tas[19].image = lisBMPRGB("./images_cartes/sept-carreau.bmp");
	tas[20].image = lisBMPRGB("./images_cartes/huit-carreau.bmp");
	tas[21].image = lisBMPRGB("./images_cartes/neuf-carreau.bmp");
	tas[22].image = lisBMPRGB("./images_cartes/dix-carreau.bmp");
	tas[23].image = lisBMPRGB("./images_cartes/valet-carreau.bmp");
	tas[24].image = lisBMPRGB("./images_cartes/dame-carreau.bmp");
	tas[25].image = lisBMPRGB("./images_cartes/roi-carreau.bmp");

	// Coeur
	tas[26].image = lisBMPRGB("./images_cartes/as-coeur.bmp");
	tas[27].image = lisBMPRGB("./images_cartes/deux-coeur.bmp");
	tas[28].image = lisBMPRGB("./images_cartes/trois-coeur.bmp");
	tas[29].image = lisBMPRGB("./images_cartes/quatre-coeur.bmp");
	tas[30].image = lisBMPRGB("./images_cartes/cinq-coeur.bmp");
	tas[31].image = lisBMPRGB("./images_cartes/six-coeur.bmp");
	tas[32].image = lisBMPRGB("./images_cartes/sept-coeur.bmp");
	tas[33].image = lisBMPRGB("./images_cartes/huit-coeur.bmp");
	tas[34].image = lisBMPRGB("./images_cartes/neuf-coeur.bmp");
	tas[35].image = lisBMPRGB("./images_cartes/dix-coeur.bmp");
	tas[36].image = lisBMPRGB("./images_cartes/valet-coeur.bmp");
	tas[37].image = lisBMPRGB("./images_cartes/dame-coeur.bmp");
	tas[38].image = lisBMPRGB("./images_cartes/roi-coeur.bmp");

	// Pique
	tas[39].image = lisBMPRGB("./images_cartes/as-pique.bmp");
	tas[40].image = lisBMPRGB("./images_cartes/deux-pique.bmp");
	tas[41].image = lisBMPRGB("./images_cartes/trois-pique.bmp");
	tas[42].image = lisBMPRGB("./images_cartes/quatre-pique.bmp");
	tas[43].image = lisBMPRGB("./images_cartes/cinq-pique.bmp");
	tas[44].image = lisBMPRGB("./images_cartes/six-pique.bmp");
	tas[45].image = lisBMPRGB("./images_cartes/sept-pique.bmp");
	tas[46].image = lisBMPRGB("./images_cartes/huit-pique.bmp");
	tas[47].image = lisBMPRGB("./images_cartes/neuf-pique.bmp");
	tas[48].image = lisBMPRGB("./images_cartes/dix-pique.bmp");
	tas[49].image = lisBMPRGB("./images_cartes/valet-pique.bmp");
	tas[50].image = lisBMPRGB("./images_cartes/dame-pique.bmp");
	tas[51].image = lisBMPRGB("./images_cartes/roi-pique.bmp");

}
