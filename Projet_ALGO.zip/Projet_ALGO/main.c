#include <stdlib.h> // Pour pouvoir utiliser exit()
#include <stdio.h>	// Pour pouvoir utiliser printf()
#include <math.h>	// Pour pouvoir utiliser sin() et cos()
#include "GfxLib.h" // Seul cet include est necessaire pour faire du graphique
#include "BmpLib.h" // Cet include permet de manipuler des fichiers BMP
#include "ESLib.h"	// Pour utiliser valeurAleatoire()
#include <string.h>
#include <time.h>
#include <unistd.h>

#include "moteur.h"
#include "fonctions.h"
#include "settings.h"



//VRAI



// Variables

static int variableboutonf2unef = 0;

/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement);

//-------------------------------------------------//
//---------------MAIN------------------------------//

int main(int argc, char **argv){
    srand(time(NULL));
    

	initialiseGfx(argc, argv);

	prepareFenetreGraphique("GfxLib", LargeurFenetre, HauteurFenetre);

	/* Lance la boucle qui aiguille les evenements sur la fonction gestionEvenement ci-apres,
		qui elle-meme utilise fonctionAffichage ci-dessous */
	
	lanceBoucleEvenements();

	return 0;
}

//------------------------------------------------//

//----------------------------------------//

extern int nbr;
extern int nbrInitial ;
extern int nbr2;
extern int choixPartie ;
extern int valeurBot ;
extern int valeurJoueur ;
extern int index_tas;
extern int variableboutonf2unef;

//----------------------------------------//



/* La fonction de gestion des evenements, appelee automatiquement par le systeme
des qu'une evenement survient */
void gestionEvenement(EvenementGfx evenement){

	static struct main main_joueur ;
	static struct main main_croupier ;
	static struct test POMME;

	static struct carte tas[NUM_CARTES];
	static valeurs vals = {0};
	static int verif_score = 0 ;
	static struct main joueur_main;
	static enum partie_de_jeu etat ;
	static bool pleinEcran = false;		  // Pour savoir si on est en mode plein ecran ou pas
	static DonneesImageRGB *titre = NULL; // L'image a afficher au centre de l'ecran
	static DonneesImageRGB *image = NULL;
	static DonneesImageRGB *logo = NULL;
	static int index_tas =0;
	 
	static int valeurMain = 0;
	static int solde_joueur ;
    static int mise = 0;
	

   
    static int score_croupier = 0;
	
	static DonneesImageRGB *dos_carte= NULL ; //image du dos de la carte pour le deck
	static DonneesImageRGB *dos_carte_croupier= NULL ;
    //--Pour l'animation des cartes--//

	static float fps_joueur_y ; 
	static float fps_joueur_x; 
	static float fps_joueur_x2 ; 
	static float fps_joueur_y2  ; 
	static float fps_croupier_y ; 
	static float fps_croupier_x; 
	static float fps_croupier_x2 ; 
	static float fps_croupier_y2  ; 

	static float fps_croupier_x_dos; 
	static float fps_croupier_x2_dos ; 
	static int verif=0;  
	static int verif_dos_carte = 0;
	switch (evenement){

	case Initialisation:
		static enum partie_de_jeu etat = Page_accueil;
		

		dos_carte = lisBMPRGB("./images_cartes/dos_carte.bmp");
		dos_carte_croupier = lisBMPRGB("./images_cartes/dos_carte.bmp");
		initialiseTas(tas);
		implementerImagesStatiques(tas);
		melangerTas(tas);


		nbr = nbrInitial;
		vals = init_val();
		mise = nbr2;
		solde_joueur = nbr;

		main_joueur.nb_cartes = 0;
		main_joueur.nb_cartes = 0;
		
		

			

		image = lisBMPRGB("./images_cartes/picturep.bmp");
		titre = lisBMPRGB("./images_cartes/acceuila.bmp");
		logo = lisBMPRGB("./images_cartes/logo.bmp");

		//----Pour l'animation des cartes -------//
		main_croupier.cartes[0]=tas[TAILLE_MAIN_MAX];
		main_croupier.cartes[1]=tas[TAILLE_MAIN_MAX+1];
		
		main_croupier.nb_cartes=2;

		main_joueur.cartes[0]=tas[0];
		main_joueur.cartes[1]=tas[1];

		
		main_joueur.nb_cartes=2;
		POMME.pomme1 = calculerValeurMain(&main_croupier);
		POMME.pomme = calculerValeurMain(&main_joueur);
		fps_joueur_y = (JOUEUR_Y-DECK_Y)/25.f ; 
		fps_joueur_x = (JOUEUR_X-DECK_X)/25.f ; 
		fps_joueur_x2 = 0 ; 
		fps_joueur_y2 = 0 ;
		fps_croupier_y = (CROUPIER_Y-DECK_Y)/20.f ; 
		fps_croupier_x = (CROUPIER_X-DECK_X)/20.f ; 
		fps_croupier_x2 = 0 ; 
		fps_croupier_y2 = 0 ;
		fps_croupier_x_dos = 10 ; 
		fps_croupier_x2_dos = 0 ;
		/* Le message "Ini*tialisation" est envoye une seule fois, au debut du
		programme : il permet de fixer "image" a la valeur qu'il devra conserver
		jusqu'a la fin du programme : soit "image" reste a NULL si l'image n'a
		pas pu etre lue, soit "image" pointera sur une structure contenant
		les caracteristiques de l'image "imageNB.bmp" */

		// Configure le systeme pour generer un message Temporisation
		// toutes les 20 millisecondes
		demandeTemporisation(20);
		break;

	case Temporisation:
		if(verif == 1){

		
			if (verif==1 && ((DECK_X )+ (fps_croupier_x2)) < CROUPIER_X){
				
				fps_croupier_x2 = fps_croupier_x2 + fps_croupier_x ;
				fps_croupier_y2 = fps_croupier_y2 + fps_croupier_y ; 
				
				if(main_croupier.nb_cartes<2){
					main_croupier.nb_cartes +=1;
					main_joueur.nb_cartes +=1;
				}
			}

			if (verif==1 && ((DECK_X )+ (fps_joueur_x2)) < JOUEUR_X){
				
				fps_joueur_x2 = fps_joueur_x2 + fps_joueur_x ;
				fps_joueur_y2 = fps_joueur_y2 + fps_joueur_y ; 
			}
			 
			if (verif_dos_carte==1 && fps_croupier_x2_dos>=-71){

				fps_croupier_x2_dos=fps_croupier_x2_dos - fps_croupier_x_dos;
			}
			else if (verif_dos_carte==1 && fps_croupier_x2_dos<=-70){
				verif_dos_carte = 2 ; 
			}
		}
		
		// Les coordonnees de la balle ayant eventuellement change,
		// il faut redessiner la fenetre :
		rafraichisFenetre();
		break;




	case Affichage:

		// On part d'un fond d'ecran blanc
		effaceFenetre(255, 255, 255);
			

		if (etat == Page_accueil)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(120,200, titre->largeurImage,titre->hauteurImage,titre->donneesRGB);
			
			Partie0(vals);
		}
		if (etat == Page_mise)
		{

			
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(1030,660,logo->largeurImage,logo->hauteurImage,logo->donneesRGB);
			Partie1(vals);
			if (dos_carte != NULL) {
				ecrisImage(DECK_X, DECK_Y, dos_carte->largeurImage, dos_carte->hauteurImage, dos_carte->donneesRGB);
			}
		}
		if (etat == Page_carte)
		{
			
			
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(1030,660,logo->largeurImage,logo->hauteurImage,logo->donneesRGB);
			
			Partie2(vals, &main_joueur, &main_croupier, &POMME);

			if (dos_carte != NULL && verif==1) {
				ecrisImage(DECK_X, DECK_Y, dos_carte->largeurImage, dos_carte->hauteurImage, dos_carte->donneesRGB);
				
			}
			
			if (dos_carte_croupier != NULL && verif==1) {
				ecrisImage(DECK_X+fps_croupier_x2+fps_croupier_x2_dos, DECK_Y+fps_croupier_y2, dos_carte_croupier->largeurImage, dos_carte_croupier->hauteurImage, dos_carte->donneesRGB);
				
			}
			
			//images des cartes du croupier
			
			if ((main_croupier.cartes[1].image) != NULL && verif==1) {
			 	ecrisImage(DECK_X+fps_croupier_x2+50, DECK_Y+fps_croupier_y2,main_croupier.cartes[1].image->largeurImage, main_croupier.cartes[1].image->hauteurImage, main_croupier.cartes[1].image->donneesRGB);
					
		 	}
				
			if ((main_croupier.cartes[0].image) != NULL && verif_dos_carte==2) {
			 	ecrisImage(DECK_X+fps_croupier_x2+fps_croupier_x2_dos, DECK_Y+fps_croupier_y2,main_croupier.cartes[0].image->largeurImage, main_croupier.cartes[0].image->hauteurImage, main_croupier.cartes[0].image->donneesRGB);
					
		 	}
			if (verif_dos_carte==2){
				for(int i =2 ; i <main_croupier.nb_cartes;i++){
					if(main_croupier.cartes[i].image != NULL){
						ecrisImage(CROUPIER_X+50*i,CROUPIER_Y,main_croupier.cartes[i].image->largeurImage,main_croupier.cartes[i].image->hauteurImage,main_croupier.cartes[i].image->donneesRGB);
					}
				}
			}
			
			
			if (verif_dos_carte==2){
				cercleBot(vals,&main_croupier,&POMME);
			}
			// for(int i = 0;i<main_croupier.nb_cartes;i++){
				
			// 	if ((main_croupier.cartes[i].image) != NULL) {
			// 		ecrisImage(DECK_X+fps_croupier_x2+(50*(i)), DECK_Y+fps_croupier_y2,main_croupier.cartes[i].image->largeurImage, main_croupier.cartes[i].image->hauteurImage, main_croupier.cartes[i].image->donneesRGB);
					
			// 	}
			// }

			for(int i = 0 ;i<main_joueur.nb_cartes;i++){
				if ((main_joueur.cartes[i].image) != NULL) {
					ecrisImage(DECK_X+fps_joueur_x2+(50*i), DECK_Y+fps_joueur_y2,main_joueur.cartes[i].image->largeurImage, main_joueur.cartes[i].image->hauteurImage, main_joueur.cartes[i].image->donneesRGB);
				}
			}

			if (dos_carte != NULL && verif==0) {
				ecrisImage(DECK_X, DECK_Y, dos_carte->largeurImage, dos_carte->hauteurImage, dos_carte->donneesRGB);
			}
		}
		if (etat == Page_Fin1)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(1030,660,logo->largeurImage,logo->hauteurImage,logo->donneesRGB);
			
			Partie3_1(vals);
		}
		if (etat == Page_Fin2)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(1030,660,logo->largeurImage,logo->hauteurImage,logo->donneesRGB);
			
			Partie3_2(vals);
		}

		if (etat == Page_Fin3)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			ecrisImage(1030,660,logo->largeurImage,logo->hauteurImage,logo->donneesRGB);
			
			Partie3_3(vals);
		}
		if (etat == Page_Abandon)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			
			Partie4_1(vals);
		}
		if (etat == Page_gameover)
		{
			ecrisImage(0,0, image->largeurImage,image->hauteurImage,image->donneesRGB);
			
			Partie4_2(vals);
		}

		break;









	case Clavier:
		printf("%c : ASCII %d\n", caractereClavier(), caractereClavier());

		switch (caractereClavier())
		{
		case 'Q': /* Pour sortir quelque peu proprement du programme */
		case 'q':
			libereDonneesImageRGB(&image); /* On libere la structure image,
			c'est plus propre, meme si on va sortir du programme juste apres */
			termineBoucleEvenements();
			break;

		case 'F':
		case 'f':
			pleinEcran = !pleinEcran; // Changement de mode plein ecran
			if (pleinEcran)
				modePleinEcran();
			else
				redimensionneFenetre(LargeurFenetre, HauteurFenetre);
			break;

		case 'R':
		case 'r':
			// Configure le systeme pour generer un message Temporisation
			// toutes les 20 millisecondes (rapide)
			demandeTemporisation(20);
			break;

		case 'L':
		case 'l':
			// Configure le systeme pour generer un message Temporisation
			// toutes les 100 millisecondes (lent)
			demandeTemporisation(100);
			break;

		case 'S':
		case 's':
			// Configure le systeme pour ne plus generer de message Temporisation
			demandeTemporisation(-1);
			break;
		}
		break;

	case ClavierSpecial:
		printf("ASCII = %d\n", toucheClavier());
		break;

	case BoutonSouris:

		int xpos = abscisseSouris();
		int ypos = ordonneeSouris();
		
		

		switch(choixPartie){
			//au début si on clique pour lancer la partie 
			case 0:
				if (etatBoutonSouris() == GaucheAppuye){ 

					if(xpos >=largeurFenetre() / 2 - 110 && xpos <= largeurFenetre() / 2 + 110 && ypos >= hauteurFenetre() / 2 - 350 && ypos <= hauteurFenetre() / 2 - 275){

						etat = Page_mise;
					}

				}
				

			break;
			//Cette partie contient les conditions des "boutons-jetons" pour ajouter de la mise
			case 1:
				if (etatBoutonSouris() == GaucheAppuye){ // verifier aussi avec bouton relacher

					if (xpos <= (largeurFenetre() / 20) + vals.distancelargeur + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle){
    					if(nbr >= 0 && nbr >= 1){
    						nbr = nbr-1;
    						nbr2 = nbr2 + 1;

    					}
    				}

    				if(xpos <= largeurFenetre() / 20 + vals.distancelargeur * 2 + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur * 2 - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle){
    					if(nbr >= 1 && nbr >= 5){
    						nbr = nbr-5;

    						nbr2 = nbr2 + 5;
    					}
					}
					if(xpos <= largeurFenetre() / 20 + vals.distancelargeur * 3 + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur * 3 - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle){
   			 			if(nbr >= 5 && nbr >= 25){
    						nbr = nbr-25;

    						nbr2 = nbr2 + 25;
    					}
    	
					}
					if(xpos <= largeurFenetre() / 20 + vals.distancelargeur * 4 + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur * 4 - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle){
    					if(nbr >= 25 && nbr >= 50){
    						nbr = nbr-50;
    						nbr2 = nbr2 + 50;
    					}
    			
					}
					if(xpos <= largeurFenetre() / 20 + vals.distancelargeur * 5 + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur * 5 - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur - vals.rayoncercle){
    					if(nbr >= 50 && nbr >= 100){
    						nbr = nbr-100;
    						nbr2 = nbr2 + 100;
    					}
    	
					}
					if(xpos <= largeurFenetre() / 20 + vals.distancelargeur + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 - vals.rayoncercle){
    					if(nbr >= 100 && nbr >= 500){
    						nbr = nbr-500;
    						nbr2 = nbr2 + 500;
    					}
    	
					}
					if(xpos <= largeurFenetre() / 20 + vals.distancelargeur * 2 + vals.rayoncercle && xpos >= largeurFenetre() / 20 + vals.distancelargeur * 2 - vals.rayoncercle && ypos <= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 + vals.rayoncercle && ypos >= (hauteurFenetre()) / 3 - vals.distancehauteur * 3 - vals.rayoncercle){
    					if(nbr >= 500 && nbr >= 1000){
    						nbr = nbr-1000;
    						nbr2 = nbr2 + 1000;
    					}
    			
					}
					if (xpos <= ((hauteurFenetre()) / 1.75) + vals.rayongroscercle && xpos >= ((hauteurFenetre()) / 1.75) - vals.rayongroscercle && ypos <= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 + vals.rayongroscercle && ypos >= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 - vals.rayongroscercle) {
       			
       					
       					nbr = nbrInitial;
       					nbr2 = 0;
       			
        			}	
					if (xpos >= ((largeurFenetre() / 3) -(largeurFenetre() / 20)) / 1.5 && xpos <= (largeurFenetre() / 3) - (largeurFenetre() / 20) && ypos >= (((hauteurFenetre()) / 3) ) && ypos <= ((hauteurFenetre()) / 3 + (25+7.25))) {
				
						nbr2 += nbr;
						nbr = 0;
					}
					if (xpos <= (((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 + 10) && (xpos >= (3 * largeurFenetre()) / 5.7 - 10) && ypos <= (hauteurFenetre() / 2 + vals.distancehauteur / 2 + 10) && ypos >= (hauteurFenetre() / 2 - vals.distancehauteur / 2 + 25) && nbr2 > 0){
							
        				etat = Page_carte;
    					verif=1;
        				
					}
       			
				}
			break;

			
			case 2:  // trois choix ici : soit on se rajoute une carte, soit on reste ou on double sa mise

				

				if (etatBoutonSouris() == GaucheAppuye)
				{
					//quand on appuie sur ajouter 
					if (xpos >= (3 * largeurFenetre()) / 17.1 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 3.66 && ypos >= hauteurFenetre() / 2 - vals.distancehauteur / 2 + 35 && ypos <= hauteurFenetre() / 2 + vals.distancehauteur / 2)
					{	
						
						POMME.pomme= calculerValeurMain(&main_joueur);
						//si la somme des cartes depasse 21
						if(POMME.pomme> SCORE_BLACKJACK){
							 
							
							if(nbr == 0 && verif_score == 1){
								sleep(1);
								etat = Page_gameover;
								nbr2 = 0;

								}

							else{
								if(verif_score==1){
								sleep(1);
								etat = Page_Fin1;
								nbr2 = 0;
								nbrInitial = nbr;
								}
							}
							verif_score = 1 ; 
						}
						main_joueur.cartes[main_joueur.nb_cartes] = tas[main_joueur.nb_cartes];
						main_joueur.nb_cartes +=1;
						

					}

					//si on clique sur rester
					else if (xpos >= (3 * largeurFenetre()) / 5.7 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 && ypos >= hauteurFenetre() / 2 - vals.distancehauteur / 2 + 35 && ypos <= hauteurFenetre() / 2 + vals.distancehauteur / 2){
						if(verif_dos_carte==0){
							verif_dos_carte= 1 ; 
						}
						
						printf("rester\n");
						printf("%d",verif_dos_carte);
						printf("\n%dC ICIVIVIVI\n",calculerValeurMain(&main_croupier));
						if(verif_dos_carte==1){
							while(calculerValeurMain(&main_croupier) < SEUIL_CROUPIER){
								if(calculerValeurMain(&main_croupier) < SEUIL_CROUPIER){
									main_croupier.cartes[main_croupier.nb_cartes] = tas[main_croupier.nb_cartes+TAILLE_MAIN_MAX];
									printf("%d", main_croupier.cartes[main_croupier.nb_cartes].rang);
									main_croupier.nb_cartes+=1 ;
											
								}
							}
						}
						if (verif_dos_carte == 2 ) {
							
							

							POMME.pomme=calculerValeurMain(&main_joueur);
							POMME.pomme1=calculerValeurMain(&main_croupier);

							if((POMME.pomme < POMME.pomme1 && POMME.pomme1 <= SCORE_BLACKJACK) || (POMME.pomme > POMME.pomme1 && POMME.pomme > SCORE_BLACKJACK)){
							
							if(nbr == 0){

								etat = Page_gameover;
								nbr2 = 0;

								}

							else{
								etat = Page_Fin1;
								nbr2 = 0;
								nbrInitial = nbr;
							}
							
						}

							else if(POMME.pomme == POMME.pomme1){

								etat = Page_Fin3;
								nbr = nbr + nbr2;
								nbr2=0;
								nbrInitial = nbr;
							}

							else if((POMME.pomme1 > SCORE_BLACKJACK && POMME.pomme <= SCORE_BLACKJACK) || (POMME.pomme > POMME.pomme1 && POMME.pomme <= SCORE_BLACKJACK)){

								etat = Page_Fin2;
								nbr = nbr + (nbr2*2);
								nbr2 = 0;
								nbrInitial = nbrInitial;
							}
							
						}

					}

					else if (xpos <= ((hauteurFenetre()) / 1.75) + vals.rayongroscercle && xpos >= ((hauteurFenetre()) / 1.75) - vals.rayongroscercle && ypos <= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 + vals.rayongroscercle && ypos >= ((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25 - vals.rayongroscercle)
					{
						POMME.pomme=calculerValeurMain(&main_joueur);
						POMME.pomme1=calculerValeurMain(&main_croupier);
						// if(POMME.pomme < SCORE_BLACKJACK){
							
							
						// 	main_joueur.cartes[main_joueur.nb_cartes] = tas[main_joueur.nb_cartes];
						// 	main_joueur.nb_cartes +=1;
						// }
						// POMME.pomme=calculerValeurMain(&main_joueur);
						// POMME.pomme1=calculerValeurMain(&main_croupier);
						if (nbr2 <= nbr && nbr2 >= 0 ){

							if(POMME.pomme == POMME.pomme1){

								nbr = nbr + (nbr2);
								
								nbrInitial = nbr;
								nbr2=0;

								etat = Page_Fin3;
							}



							else if(POMME.pomme < POMME.pomme1){

								if(nbr == 0){
									etat = Page_gameover;
									nbrInitial = nbr;
									nbr2 = 0;
								}
								else{
									etat = Page_Fin1;
									nbr = nbr - nbr2;
									nbrInitial = nbr;
									nbr2 = 0;
								}
							
							}

							else if(POMME.pomme > POMME.pomme1){

								

								nbr = nbr + (nbr2 * 2);
								nbrInitial = nbr;
								nbr2 = 0;
								etat = Page_Fin2;
							}



						}

						
					}


				}

			break;

			case 31:


				if (etatBoutonSouris() == GaucheAppuye)
				{

					if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 40 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 300 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
					{
						printf("Abandonner1\n");
						etat=Page_Abandon;
					}

					else if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 290 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 50 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
					{
						printf("Continuer1\n");
						
						melangerTas(tas);
							
						main_croupier.cartes[0]=tas[TAILLE_MAIN_MAX];
						main_croupier.cartes[1]=tas[TAILLE_MAIN_MAX+1];
						main_croupier.nb_cartes=2;

						main_joueur.cartes[0]=tas[0];
						main_joueur.cartes[1]=tas[1];
						main_joueur.nb_cartes=2;
						
						etat=Page_mise;
						verif=0;
						verif_dos_carte=0;
						POMME.pomme1 = calculerValeurMain(&main_croupier);
						fps_joueur_y = (JOUEUR_Y-DECK_Y)/25.f ; 
						fps_joueur_x = (JOUEUR_X-DECK_X)/25.f ; 
						fps_joueur_x2 = 0 ; 
						fps_joueur_y2 = 0 ;
						fps_croupier_y = (CROUPIER_Y-DECK_Y)/20.f ; 
						fps_croupier_x = (CROUPIER_X-DECK_X)/20.f ; 
						fps_croupier_x2 = 0 ; 
						fps_croupier_y2 = 0 ;
						fps_croupier_x_dos = 10 ; 
						fps_croupier_x2_dos = 0 ;
						
					}
				}

				break;

			case 32:

				if (etatBoutonSouris() == GaucheAppuye)
				{

					if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 40 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 300 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
					{
						printf("Abandonner2\n");
						etat=Page_Abandon;
					}

					else if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 290 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 50 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
					{
						printf("Continuer2\n");
						
						melangerTas(tas);
							
						main_croupier.cartes[0]=tas[TAILLE_MAIN_MAX];
						main_croupier.cartes[1]=tas[TAILLE_MAIN_MAX+1];
						main_croupier.nb_cartes=2;

						main_joueur.cartes[0]=tas[0];
						main_joueur.cartes[1]=tas[1];
						main_joueur.nb_cartes=2;
						etat=Page_mise;
						verif=0;
						verif_dos_carte=0;
						main_joueur.nb_cartes=2;
						POMME.pomme1 = calculerValeurMain(&main_croupier);
						fps_joueur_y = (JOUEUR_Y-DECK_Y)/25.f ; 
						fps_joueur_x = (JOUEUR_X-DECK_X)/25.f ; 
						fps_joueur_x2 = 0 ; 
						fps_joueur_y2 = 0 ;
						fps_croupier_y = (CROUPIER_Y-DECK_Y)/20.f ; 
						fps_croupier_x = (CROUPIER_X-DECK_X)/20.f ; 
						fps_croupier_x2 = 0 ; 
						fps_croupier_y2 = 0 ;
						fps_croupier_x_dos = 10 ; 
						fps_croupier_x2_dos = 0 ;
						
						
				}
			}

			break;

		case 33:

			if (etatBoutonSouris() == GaucheAppuye)
			{

				if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 40 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 300 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
				{
					printf("Abandonner3\n");
					etat=Page_Abandon;
				}

				else if (xpos >= ((hauteurFenetre()) / 1.75) / 2 + 290 && xpos <= ((3 * largeurFenetre()) / 4 + vals.distancelargeur) / 1.43 - 50 && ypos <= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 206 && ypos >= (((hauteurFenetre()) / 3 + vals.distancehauteur) * 1.25) - 250)
				{
					printf("Continuer3\n");

					 
					 melangerTas(tas);
						
					main_croupier.cartes[0]=tas[TAILLE_MAIN_MAX];
					main_croupier.cartes[1]=tas[TAILLE_MAIN_MAX+1];
					main_croupier.nb_cartes=2;

					main_joueur.cartes[0]=tas[0];
					main_joueur.cartes[1]=tas[1];
					main_joueur.nb_cartes=2;
					etat=Page_mise;
					verif=0;
					verif_dos_carte=0;
					main_joueur.nb_cartes=2;
					POMME.pomme1 = calculerValeurMain(&main_croupier);
					fps_joueur_y = (JOUEUR_Y-DECK_Y)/25.f ; 
					fps_joueur_x = (JOUEUR_X-DECK_X)/25.f ; 
					fps_joueur_x2 = 0 ; 
					fps_joueur_y2 = 0 ;
					fps_croupier_y = (CROUPIER_Y-DECK_Y)/20.f ; 
					fps_croupier_x = (CROUPIER_X-DECK_X)/20.f ; 
					fps_croupier_x2 = 0 ; 
					fps_croupier_y2 = 0 ;
					fps_croupier_x_dos = 10 ; 
					fps_croupier_x2_dos = 0 ;
					
				}
			}

			break;


		case 41:
			if (etatBoutonSouris() == GaucheAppuye)
			{

				if (xpos >= largeurFenetre() / 2 + 50 && xpos <= largeurFenetre() / 2 - 50 && ypos >= hauteurFenetre() / 2 - 320 && ypos >= largeurFenetre() / 2 - 50)
				{
					printf("OKA");
					etat = Page_accueil;
				}
			}
			break;
		default:
			break;
		}

		break;


		break;

	case Souris: // Si la souris est deplacee
		break;

	case Inactivite: // Quand aucun message n'est disponible
		break;

	case Redimensionnement: // La taille de la fenetre a ete modifie ou on est passe en plein ecran
		// Donc le systeme nous en informe
		
		break;
	}
}













































