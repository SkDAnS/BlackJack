#ifndef SETTINGS_H
#define SETTINGS_H

#define LargeurFenetre 1200
#define HauteurFenetre 800
#define NUM_CARTES 52
#define TAILLE_MAIN_MAX 12
#define SEUIL_CROUPIER 17
#define SCORE_BLACKJACK 21
#define FAMILLE 4
#define CROUPIER_Y 530
#define CROUPIER_X 350
#define JOUEUR_Y 130
#define JOUEUR_X 350
#define DECK_Y 530
#define DECK_X 30	






#endif 