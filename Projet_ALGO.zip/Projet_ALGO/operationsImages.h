#ifndef OPERATIONS_IMAGES
#define OPERATIONS_IMAGES

#define N 256

void cree3matrices(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], const DonneesImageRGB* image);

void creeImage(const unsigned char r[N][N], const unsigned char v[N][N],
	const unsigned char b[N][N], DonneesImageRGB* image);

void negatifImage(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void rougeImage(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void vertImage(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void bleuImage(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void couleurNiveauDeGris_naif(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void couleurNiveauDeGris(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image);

void seuillageNiveauDeGris(unsigned char r[N][N], unsigned char v[N][N],
	unsigned char b[N][N], DonneesImageRGB* image, unsigned char seuil);

#endif
