#ifndef FONCTIONS_H
#define FONCTIONS_H

#include "moteur.h"
#include "settings.h"

// Fonction de trace de cercle
void cercle(float centreX, float centreY, float rayon);




enum partie_de_jeu{
	Page_accueil,
	Page_mise,
	Page_carte,
	Page_Fin1,
	Page_Abandon,
	Page_gameover,
	Page_Fin2,
	Page_Fin3
};



typedef struct {
	int distancelargeur ;
	int distancehauteur ;
	int rayoncercle ;
	int rayoncercle2 ;
	int rayongroscercle ;
	int rayongroscercle2 ;
}valeurs;



// Fonction cree
void traceGraphique();

valeurs init_val();
void cercle(float centreX, float centreY, float rayon);
void afficheFondecran();
void cercleBot(valeurs vals, struct main *main_croupier,struct test *POMME);
void cercleJoueur(valeurs vals,struct main *main_joueur,struct test *POMME);
void cercle1(valeurs vals);
void cercle5(valeurs vals);
void cercle25(valeurs vals);
void GrosCercle50(valeurs vals);
void GrosCercle100(valeurs vals);
void GrosCercle500(valeurs vals);
void GrosCercle1000(valeurs vals);
void affichepetiteBanque(valeurs vals,char tab3[5]);
void afficheBoutonRester(valeurs vals,int r, int g, int v);
void afficheBoutonAjouterCarte(valeurs vals,int r, int g, int v);
void BoutonDONNE(valeurs vals,int r, int g, int v);
void GagnerBas(valeurs vals);
void PerdueHaut(valeurs vals);
void PerdueBas(valeurs vals);
void GagnerHaut(valeurs vals);
void EgaliterHaut(valeurs vals);
void EgaliterBas(valeurs vals);
void BlocAbondon(valeurs vals,char tab8[50]);
void BlocGameOver(valeurs vals);
void DoubleouRien(valeurs vals);
void petitBoutonAbandoner(valeurs vals);
void petitBoutonContinuer(valeurs vals);

void Partie0(valeurs vals);
int Partie1(valeurs vals);

void Partie2(valeurs vals, struct main *main_joueur, struct main *main_croupier, struct test *POMME);
void Partie3_1(valeurs vals);
void Partie3_2(valeurs vals);
void Partie3_3(valeurs vals);
void Partie4_1(valeurs vals);
void Partie4_2(valeurs vals);


void implementerImagesStatiques(struct carte tas[NUM_CARTES]);


#endif